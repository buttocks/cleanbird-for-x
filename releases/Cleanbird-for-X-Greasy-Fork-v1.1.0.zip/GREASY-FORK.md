# Greasy Fork listing

## Script name

Cleanbird for X

## Short description

A configurable, responsive cleanup interface for X and Twitter in Firefox.

## Additional information

Cleanbird for X is a configurable, responsive cleanup layer for the logged-in
X website. It keeps normal X features—including posting, replies,
notifications, and your existing login—while removing clutter and making
better use of wide screens. It runs on both `x.com` and `twitter.com`.

### Features

- Responsive feed, navigation, sidebars, menus, and text
- Full-width and narrow-reading layouts
- Home-tab organizer that can move any detected top-bar tab left or right
- Optional removal of promoted posts, Grok, Chat, Premium, Jobs, trends,
  suggestions, view counts, and footer links
- Compact posts, reduced motion, softer engagement metrics, and disabled video
  autoplay
- Following feed selected automatically when available
- Built-in BR branding with custom-logo support

### Settings

Open **More → BR settings** on X, or press **Alt+Shift+C**. Every cleanup,
layout, and tab-order option can be changed independently.

### Privacy

Cleanbird uses your existing X browser session. It never asks for or stores
your X password and does not send analytics or personal information anywhere.
Preferences and custom branding are stored locally by the userscript manager.

### Compatibility

Designed for Firefox with Violentmonkey or Tampermonkey. Because X frequently
changes its interface, occasional selector updates may be required.

### Source and support

https://github.com/buttocks/cleanbird-for-x

## Code to submit

Submit the complete contents of `Cleanbird-for-X-Greasy-Fork-v1.1.0.user.js`.
Its public namespace is deliberately different from the older local build, so
it installs as a separate userscript instead of replacing that copy. Keep only
one Cleanbird script enabled at a time. Do not add a Greasy Fork `@downloadURL`
or `@updateURL`; Greasy Fork generates those fields.
